"""
Vehicle Scanner — Standalone Backend Model Pipeline (No Flask / No Server)
========================================================================
Clean model integration pipeline for:
1. VIN Scan   → Preprocessing + OCR + 17-character VIN extraction & validation
2. Tyre Scan  → YOLO region detection + Preprocessing + OCR + Tyre size parsing
3. Model Export → Tools to export custom YOLO weights (.pt) to TFLite for Android

No web server or Flask dependencies required.
"""

from pathlib import Path
import re
import os
import sys
import argparse
import json

os.environ["PADDLE_PDX_ENABLE_MKLDNN_BYDEFAULT"] = "0"
os.environ["FLAGS_use_mkldnn"] = "0"

import cv2
import numpy as np
from ultralytics import YOLO
from paddleocr import PaddleOCR

# ─── Paths ───────────────────────────────────────────────────────────────────
BASE_DIR = Path(__file__).resolve().parent
MODEL_PATH = BASE_DIR / "models" / "best.pt"
ANDROID_ASSETS_DIR = BASE_DIR / "android_app" / "app" / "src" / "main" / "assets"

# ─── Model initialisation ───────────────────────────────────────────────────
# YOLO custom detector for tyre sidewall regions (loads custom best.pt if present, else yolo11n fallback).
if MODEL_PATH.exists():
    yolo_model = YOLO(str(MODEL_PATH))
    print(f"[Backend] Loaded custom tyre YOLO model from {MODEL_PATH}")
elif (BASE_DIR / "yolo11n.pt").exists():
    yolo_model = YOLO(str(BASE_DIR / "yolo11n.pt"))
    print("[Backend] Loaded yolo11n.pt fallback")
else:
    yolo_model = None

# PaddleOCR 3.x — shared engine for VIN and Tyre modes.
ocr_engine = PaddleOCR(
    lang="en",
    use_doc_orientation_classify=False,
    use_doc_unwarping=False,
    use_textline_orientation=False,
    device="cpu",
    enable_mkldnn=False,
)

# ═════════════════════════════════════════════════════════════════════════════
# IMAGE PREPROCESSING UTILITIES
# ═════════════════════════════════════════════════════════════════════════════

def load_and_resize(path_or_image, max_edge=2400):
    """Load image from path or validate numpy array; resize if needed."""
    if isinstance(path_or_image, (str, Path)):
        image = cv2.imread(str(path_or_image))
        if image is None:
            raise ValueError(f"Could not open image at {path_or_image}.")
    elif isinstance(path_or_image, np.ndarray):
        image = path_or_image
    else:
        raise TypeError("Expected image path or numpy ndarray.")

    h, w = image.shape[:2]
    if max(h, w) > max_edge:
        scale = max_edge / max(h, w)
        image = cv2.resize(image, (int(w * scale), int(h * scale)),
                           interpolation=cv2.INTER_AREA)
    return image


def preprocess_variants(image):
    """Generate enhanced image variants covering real-world lighting conditions:
    1. Original frame
    2. CLAHE local contrast (general & overcast/cloudy conditions)
    3. Edge sharpened CLAHE (accentuates subtle embossed rubber ridges)
    4. Shadow lift (gamma 0.55 for car parked under shade / dark wheel well)
    5. Sunlight glare suppression (gamma 1.35 + CLAHE for harsh direct sun)
    6. Inverted high-contrast (dark-on-dark embossed tyre letters)
    """
    variants = [image]
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    clahe = cv2.createCLAHE(clipLimit=2.2, tileGridSize=(8, 8)).apply(gray)
    variants.append(cv2.cvtColor(clahe, cv2.COLOR_GRAY2BGR))

    # 3. Sharpened CLAHE (for low-contrast cloudy / overcast days)
    blur = cv2.GaussianBlur(clahe, (0, 0), 2.0)
    sharp = cv2.addWeighted(clahe, 1.7, blur, -0.7, 0)
    variants.append(cv2.cvtColor(sharp, cv2.COLOR_GRAY2BGR))

    # 4. Shadow Lift for shaded areas (gamma < 1.0)
    inv_gamma = 1.0 / 0.55
    table_shade = np.array([((i / 255.0) ** (1.0 / inv_gamma)) * 255 for i in np.arange(0, 256)]).astype("uint8")
    shade_lifted = cv2.LUT(clahe, table_shade)
    variants.append(cv2.cvtColor(shade_lifted, cv2.COLOR_GRAY2BGR))

    # 5. Sunlight Glare Suppression (gamma > 1.0)
    table_sun = np.array([((i / 255.0) ** 1.35) * 255 for i in np.arange(0, 256)]).astype("uint8")
    sun_suppressed = cv2.LUT(clahe, table_sun)
    variants.append(cv2.cvtColor(sun_suppressed, cv2.COLOR_GRAY2BGR))

    # 6. Inverted high contrast
    inverted = cv2.bitwise_not(sharp)
    variants.append(cv2.cvtColor(inverted, cv2.COLOR_GRAY2BGR))

    return variants


def unpack_paddle(results):
    """Extract (text, confidence) pairs from PaddleOCR result objects."""
    found = []
    for item in (results or []):
        data = None
        try:
            data = item.get("res", item) if hasattr(item, "get") else None
        except Exception:
            data = None
        if data is None:
            try:
                data = item.json.get("res", item.json)
            except Exception:
                data = {}

        texts = data.get("rec_texts", []) if isinstance(data, dict) else []
        scores = data.get("rec_scores", []) if isinstance(data, dict) else []

        for i, text in enumerate(texts):
            score = float(scores[i]) if i < len(scores) else 0.0
            cleaned = str(text).strip()
            if cleaned:
                found.append({"text": cleaned, "confidence": round(score, 4)})
    return found


def run_paddle_on_image(image):
    """Run PaddleOCR on a cv2 image or file path."""
    results = ocr_engine.predict(image)
    return unpack_paddle(results)


# ═════════════════════════════════════════════════════════════════════════════
# VIN SCAN PIPELINE
# ═════════════════════════════════════════════════════════════════════════════

VIN_PATTERN = re.compile(r"[A-HJ-NPR-Z0-9]{17}")


def vin_preprocess(image):
    """Enlarge small images and create contrast-enhanced variant."""
    h, w = image.shape[:2]
    if max(h, w) < 1400:
        image = cv2.resize(image, None, fx=2.0, fy=2.0,
                           interpolation=cv2.INTER_CUBIC)
    if max(image.shape[:2]) > 2400:
        scale = 2400 / max(image.shape[:2])
        image = cv2.resize(image, None, fx=scale, fy=scale,
                           interpolation=cv2.INTER_AREA)
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    enhanced = clahe.apply(gray)
    enhanced_bgr = cv2.cvtColor(enhanced, cv2.COLOR_GRAY2BGR)
    return image, enhanced_bgr


# def find_vin_candidates(text_items):
#     """Search recognised text for 17-character VIN candidates."""
#     candidates = []
#     for item in text_items:
#         raw = item["text"].upper()
#         compact = re.sub(r"[^A-Z0-9]", "", raw)
#         for match in re.finditer(r"[A-Z0-9]{17}", compact):
#             candidate = match.group(0)
#             valid = bool(VIN_PATTERN.fullmatch(candidate))
#             candidates.append({
#                 "vin": candidate,
#                 "confidence": item["confidence"],
#                 "valid_standard_characters": valid,
#                 "source_text": raw,
#             })
#     best = {}
#     for c in candidates:
#         key = c["vin"]
#         if key not in best or c["confidence"] > best[key]["confidence"]:
#             best[key] = c
#     return sorted(best.values(), key=lambda x: x["confidence"], reverse=True)


def validate_vin_check_digit(vin):
    """Validate the check digit used by North American VIN standards."""
    vin = vin.upper()

    if not VIN_PATTERN.fullmatch(vin):
        return {
            "applicable": False,
            "valid": False,
            "message": "Invalid VIN characters or length."
        }

    values = {
        **{str(i): i for i in range(10)},
        **dict(zip("ABCDEFGH", range(1, 9))),
        "J": 1, "K": 2, "L": 3, "M": 4, "N": 5,
        "P": 7, "R": 9, "S": 2, "T": 3, "U": 4,
        "V": 5, "W": 6, "X": 7, "Y": 8, "Z": 9,
    }

    weights = [8, 7, 6, 5, 4, 3, 2, 10, 0, 9, 8, 7, 6, 5, 4, 3, 2]

    total = sum(
        values[ch] * weight
        for ch, weight in zip(vin, weights)
    )

    remainder = total % 11
    expected = "X" if remainder == 10 else str(remainder)
    actual = vin[8]

    return {
        "applicable": True,
        "valid": actual == expected,
        "expected_check_digit": expected,
        "actual_check_digit": actual,
        "message": (
            "Check digit matches."
            if actual == expected
            else "Check digit mismatch; verify manually."
        )
    }


def find_vin_candidates(text_items):
    """Extract and validate standard 17-character VIN candidates."""
    candidates = []

    for item in text_items:
        raw = item["text"].upper()

        # Remove spaces, hyphens and punctuation for OCR normalization.
        compact = re.sub(r"[^A-Z0-9]", "", raw)

        # Find 17-character sequences.
        for match in re.finditer(r"[A-Z0-9]{17}", compact):
            candidate = match.group(0)
            start, end = match.span()

            # Reject a substring of a longer alphanumeric sequence.
            if start > 0 and compact[start - 1].isalnum():
                continue
            if end < len(compact) and compact[end].isalnum():
                continue

            valid_chars = bool(VIN_PATTERN.fullmatch(candidate))

            check_digit = (
                validate_vin_check_digit(candidate)
                if valid_chars else None
            )

            candidates.append({
                "vin": candidate,
                "confidence": item["confidence"],
                "valid_standard_characters": valid_chars,
                "check_digit_validation": check_digit,
                "source_text": raw,
            })

    # Keep the highest-confidence result for each VIN.
    best = {}

    for candidate in candidates:
        key = candidate["vin"]
        if (
            key not in best
            or candidate["confidence"] > best[key]["confidence"]
        ):
            best[key] = candidate

    return sorted(
        best.values(),
        key=lambda x: x["confidence"],
        reverse=True
    )


def process_vin(path_or_image):
    """Full VIN scanning pipeline."""
    image = load_and_resize(path_or_image)
    original, enhanced = vin_preprocess(image)

    items_orig = run_paddle_on_image(original)
    items_enh = run_paddle_on_image(enhanced)
    combined = items_orig + items_enh

    unique = {}
    for item in combined:
        key = re.sub(r"\s+", "", item["text"]).upper()
        if key not in unique or item["confidence"] > unique[key]["confidence"]:
            unique[key] = item
    text_items = sorted(unique.values(), key=lambda x: x["confidence"], reverse=True)

    candidates = find_vin_candidates(text_items)
    chosen = candidates[0] if candidates else None

    # if chosen:
    #     if not chosen["valid_standard_characters"]:
    #         status = "Candidate found, but contains non-standard characters (I, O, Q)."
    #     elif chosen["confidence"] < 0.75:
    #         status = "Low-confidence candidate. Please confirm characters manually."
    #     else:
    #         status = "Standard 17-character VIN identified successfully."
    # else:
    #     status = "No 17-character VIN candidate found."
     
    if chosen:
        if not chosen["valid_standard_characters"]:
            status = "Invalid VIN characters. Please verify manually."
        elif chosen["confidence"] < 0.75:
            status = "Low OCR confidence. Please verify manually."
        elif not chosen["check_digit_validation"]["valid"]:
            status = "Check digit mismatch. Please verify the VIN."
        else:
            status = "VIN candidate identified. Confirm market validity."
    else:
        status = "No 17-character VIN candidate found."

    return {
        "mode": "vin",
        "text_items": text_items,
        "candidates": candidates,
        "chosen": chosen,
        "status": status,
    }

# ═════════════════════════════════════════════════════════════════════════════
# TYRE SCAN PIPELINE
# ═════════════════════════════════════════════════════════════════════════════

# TYRE_PATTERN = re.compile(
#     r"(?<!\d)(?P<width>\d{3})\s*[/ -]?\s*(?P<aspect>\d{2})\s*"
#     r"(?P<construction>(?:ZR|R|Z|B|D))\s*(?P<rim>\d{2}(?:\.\d)?)\s*"
#     r"(?:(?P<load>\d{2,3})\s*(?P<speed>[A-Z]))?",
#     re.IGNORECASE,
# )


import re

# Supports common metric passenger, commercial, and motorcycle sizes:
# 205/55R16 91V
# 195/65 R15 91H
# 31x10.50R15
# 7.50R16
# 90/90-18
# 120/70ZR17
# 275/70R22.5
# 185R14C

TYRE_PATTERNS = [
    # 1. Metric size with aspect ratio and construction
    # 205/55R16, 205/55ZR16, 120/70ZR17
    re.compile(
        r"(?<![A-Z0-9])"
        r"(?P<width>\d{3})\s*/\s*"
        r"(?P<aspect>\d{2,3})\s*"
        r"(?P<construction>ZR|R|Z|B|D)\s*"
        r"(?P<rim>\d{2}(?:\.\d)?)"
        r"(?:\s*(?P<load>\d{2,3})\s*(?P<speed>[A-Z]))?"
        r"(?![A-Z0-9])",
        re.IGNORECASE,
    ),

    # 2. Metric size without slash, e.g. 195 65 R15
    re.compile(
        r"(?<![A-Z0-9])"
        r"(?P<width>\d{3})\s+"
        r"(?P<aspect>\d{2,3})\s*"
        r"(?P<construction>ZR|R|Z|B|D)\s*"
        r"(?P<rim>\d{2}(?:\.\d)?)"
        r"(?:\s*(?P<load>\d{2,3})\s*(?P<speed>[A-Z]))?"
        r"(?![A-Z0-9])",
        re.IGNORECASE,
    ),

    # 3. Commercial / light-truck size without aspect ratio
    # 7.50R16, 185R14C
    re.compile(
        r"(?<![A-Z0-9])"
        r"(?P<width>\d{3}|\d{1,2}\.\d{1,2})\s*"
        r"(?P<construction>ZR|R|Z|B|D)\s*"
        r"(?P<rim>\d{2}(?:\.\d)?)"
        r"(?:\s*(?P<load>\d{2,3})\s*(?P<speed>[A-Z]))?"
        r"(?:\s*C)?"
        r"(?![A-Z0-9])",
        re.IGNORECASE,
    ),

    # 4. Flotation / off-road size, e.g. 31x10.50R15
    re.compile(
        r"(?<![A-Z0-9])"
        r"(?P<overall_diameter>\d{2,3}(?:\.\d{1,2})?)\s*[Xx×]\s*"
        r"(?P<section_width>\d{1,2}(?:\.\d{1,2})?)\s*"
        r"(?P<construction>ZR|R|B|D)?\s*"
        r"(?P<rim>\d{2}(?:\.\d)?)"
        r"(?![A-Z0-9])",
        re.IGNORECASE,
    ),

    # 5. Motorcycle / metric format using a dash, e.g. 90/90-18
    re.compile(
        r"(?<![A-Z0-9])"
        r"(?P<width>\d{2,3})\s*/\s*"
        r"(?P<aspect>\d{2,3})\s*-\s*"
        r"(?P<rim>\d{2}(?:\.\d)?)"
        r"(?![A-Z0-9])",
        re.IGNORECASE,
    ),
]

SPEED_RATINGS = {
    "A1": 5, "A2": 10, "A3": 15, "A4": 20, "A5": 25, "A6": 30,
    "A7": 35, "A8": 40, "B": 50, "C": 60, "D": 65, "E": 70,
    "F": 80, "G": 90, "J": 100, "K": 110, "L": 120, "M": 130,
    "N": 140, "P": 150, "Q": 160, "R": 170, "S": 180, "T": 190,
    "U": 200, "H": 210, "V": 240, "W": 270, "Y": 300,
}


def detect_tyre_regions(image):
    """Use YOLO to detect tyre marking region(s) or fallback to center reticle crop."""
    h, w = image.shape[:2]
    regions = []

    if yolo_model is not None:
        result = yolo_model.predict(source=image, conf=0.20, imgsz=640, verbose=False)[0]
        if result.boxes is not None and len(result.boxes) > 0:
            boxes = result.boxes.xyxy.cpu().numpy().astype(int)
            confs = result.boxes.conf.cpu().numpy()
            for i, (box, conf) in enumerate(zip(boxes, confs)):
                x1, y1, x2, y2 = box.tolist()
                px, py = int((x2 - x1) * 0.08), int((y2 - y1) * 0.12)
                x1, y1 = max(0, x1 - px), max(0, y1 - py)
                x2, y2 = min(w, x2 + px), min(h, y2 + py)
                if x2 > x1 and y2 > y1:
                    regions.append((image[y1:y2, x1:x2], f"yolo_region_{i + 1}", float(conf)))
            if regions:
                return regions, "YOLO detector localised marking regions."

    # Center viewfinder reticle ROI
    ymin, ymax = int(h * 0.20), int(h * 0.80)
    xmin, xmax = int(w * 0.05), int(w * 0.95)
    if ymax > ymin and xmax > xmin:
        regions.append((image[ymin:ymax, xmin:xmax], "viewfinder_center_roi", None))
    regions.append((image, "full_image_fallback", None))

    return regions, "Viewfinder center ROI + Full image fallback."


# def run_tyre_ocr(image):
#     """OCR across preprocessing variants, deduplicating results."""
#     all_text, seen = [], set()
#     for variant in preprocess_variants(image):
#         items = run_paddle_on_image(variant)
#         for item in items:
#             key = re.sub(r"\W+", "", item["text"].upper())
#             if item["text"] and key not in seen:
#                 seen.add(key)
#                 all_text.append(item)
#     return all_text
  
def run_tyre_ocr(image):
    """Run OCR on enhanced images at multiple orientations."""
    all_text = []
    seen = set()

    # Try the original image and three rotations.
    for angle in (0, 90, 270, 180):
        if angle == 0:
            rotated = image
        elif angle == 90:
            rotated = cv2.rotate(
                image, cv2.ROTATE_90_CLOCKWISE
            )
        elif angle == 270:
            rotated = cv2.rotate(
                image, cv2.ROTATE_90_COUNTERCLOCKWISE
            )
        else:
            rotated = cv2.rotate(
                image, cv2.ROTATE_180
            )

        for variant in preprocess_variants(rotated):
            try:
                items = run_paddle_on_image(variant)
            except Exception as exc:
                print(f"[OCR] Angle {angle} failed: {exc}")
                continue

            for item in items:
                text = item["text"].strip()
                key = re.sub(r"[^A-Z0-9]", "", text.upper())

                if key and key not in seen:
                    seen.add(key)
                    all_text.append({
                        **item,
                        "rotation": angle
                    })

    return all_text



# def parse_tyre(text):
#     """Match tyre size pattern from concatenated OCR text."""
#     normalised = text.upper().replace("O", "0").replace("—", "-").replace("–", "-")
#     match = TYRE_PATTERN.search(normalised)
#     if not match:
#         return {"found": False, "message": "Tyre size pattern not found."}
#     d = match.groupdict()
#     speed = d.get("speed")
#     return {
#         "found": True,
#         "size": f"{d['width']}/{d['aspect']}{d['construction'].upper()}{d['rim']}",
#         "width_mm": int(d["width"]),
#         "aspect_ratio_percent": int(d["aspect"]),
#         "construction": ("Radial" if d["construction"].upper() == "R" else "Belted / Other"),
#         "rim_diameter_inches": float(d["rim"]),
#         "load_index": int(d["load"]) if d.get("load") else None,
#         "speed_rating": speed,
#         "speed_rating_kmh": SPEED_RATINGS.get(speed) if speed else None,
#         "matched_text": match.group(0).strip(),
#     }


def parse_tyre(text):
    """Parse common tyre-size formats from OCR text."""

    normalised = (
        text.upper()
        .replace("—", "-")
        .replace("–", "-")
        .replace("×", "X")
    )

    # OCR can confuse O with 0. Avoid globally replacing O,
    # because O may occur in other sidewall markings.
    candidates = []

    for pattern in TYRE_PATTERNS:
        match = pattern.search(normalised)

        if match:
            data = match.groupdict()
            candidates.append((match, data))
            break

    if not candidates:
        return {
            "found": False,
            "message": "No supported tyre-size pattern found.",
            "raw_text": text,
        }

    match, d = candidates[0]

    # Flotation format: 31x10.50R15
    if d.get("overall_diameter"):
        return {
            "found": True,
            "format": "flotation",
            "overall_diameter_inches": float(d["overall_diameter"]),
            "section_width_inches": float(d["section_width"]),
            "rim_diameter_inches": float(d["rim"]),
            "construction": d.get("construction"),
            "matched_text": match.group(0).strip(),
        }

    # Parse standard metric / commercial / motorcycle formats.
    width_raw = d.get("width")
    aspect_raw = d.get("aspect")
    construction = (d.get("construction") or "").upper()
    rim_raw = d.get("rim")

    result = {
        "found": True,
        "format": "metric",
        "width_mm": (
            float(width_raw) if width_raw and "." in width_raw
            else int(width_raw) if width_raw else None
        ),
        "aspect_ratio_percent": (
            int(aspect_raw) if aspect_raw else None
        ),
        "construction_code": construction or None,
        "construction": (
            "Radial" if construction in ("R", "ZR")
            else "Belted" if construction == "B"
            else "Diagonal / Other" if construction in ("D", "Z")
            else "Not specified"
        ),
        "rim_diameter_inches": float(rim_raw) if rim_raw else None,
        "load_index": int(d["load"]) if d.get("load") else None,
        "speed_rating": d.get("speed"),
        "matched_text": match.group(0).strip(),
    }

    return result



def process_tyre(path_or_image):
    """Full tyre scanning pipeline."""
    image = load_and_resize(path_or_image)
    regions, detector_msg = detect_tyre_regions(image)

    region_results = []
    for crop, name, yolo_conf in regions:
        if crop.size == 0:
            continue
        texts = run_tyre_ocr(crop)
        combined = " ".join(t["text"] for t in texts)
        parsed = parse_tyre(combined)
        region_results.append({
            "region": name,
            "yolo_confidence": yolo_conf,
            "texts": texts,
            "combined_text": combined,
            "specifications": parsed,
        })

    region_results.sort(
        key=lambda x: (x["specifications"].get("found", False), len(x["combined_text"])),
        reverse=True,
    )
    best = (region_results[0] if region_results
            else {"texts": [], "combined_text": "",
                  "specifications": {"found": False, "message": "No readable text detected."}})

    return {
        "mode": "tyre",
        "detector": detector_msg,
        "custom_yolo_enabled": yolo_model is not None,
        "image_width": image.shape[1],
        "image_height": image.shape[0],
        "results": region_results,
        "best": best,
    }


# ═════════════════════════════════════════════════════════════════════════════
# EXPORT MODEL FOR ANDROID (TFLITE)
# ═════════════════════════════════════════════════════════════════════════════

def export_yolo_to_android(model_weights_path=None, output_assets_dir=ANDROID_ASSETS_DIR):
    """Export YOLO weights (.pt) to TFLite for direct on-device Android integration."""
    weights = model_weights_path or MODEL_PATH
    if not Path(weights).exists():
        if (BASE_DIR / "yolo11n.pt").exists():
            weights = BASE_DIR / "yolo11n.pt"
        else:
            raise FileNotFoundError(f"Model weights not found at {weights}")

    print(f"[Export] Loading YOLO model from {weights}...")
    model = YOLO(str(weights))
    print("[Export] Exporting to TFLite (LiteRT format) with imgsz=640...")
    exported_path = model.export(format="tflite", imgsz=640)
    print(f"[Export] Export completed: {exported_path}")

    # Copy to android assets directory
    out_dir = Path(output_assets_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    target_file = out_dir / "tyre_detector.tflite"

    src_file = Path(exported_path)
    if src_file.is_dir():
        # Look for .tflite inside folder
        tflites = list(src_file.glob("*.tflite"))
        if tflites:
            src_file = tflites[0]

    if src_file.exists():
        import shutil
        shutil.copy2(src_file, target_file)
        print(f"[Export] Copied model to Android assets: {target_file}")
    return target_file


# ═════════════════════════════════════════════════════════════════════════════
# CLI ENTRY POINT
# ═════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Standalone Vehicle Scanner Model Pipeline")
    parser.add_argument("--mode", choices=["vin", "tyre"], help="Processing mode: vin or tyre")
    parser.add_argument("--image", type=str, help="Path to input image file")
    parser.add_argument("--export-android", action="store_true", help="Export YOLO model to Android assets folder as TFLite")
    parser.add_argument("--weights", type=str, default=None, help="Optional path to custom YOLO .pt weights")

    args = parser.parse_args()

    if args.export_android:
        export_yolo_to_android(args.weights)
        sys.exit(0)

    if not args.image or not args.mode:
        print("Usage examples:")
        print("  python app.py --mode vin --image path/to/vin.jpg")
        print("  python app.py --mode tyre --image path/to/tyre.jpg")
        print("  python app.py --export-android")
        sys.exit(1)

    if args.mode == "vin":
        res = process_vin(args.image)
        print(json.dumps(res, indent=2, ensure_ascii=False))
    elif args.mode == "tyre":
        res = process_tyre(args.image)
        print(json.dumps(res, indent=2, ensure_ascii=False))
