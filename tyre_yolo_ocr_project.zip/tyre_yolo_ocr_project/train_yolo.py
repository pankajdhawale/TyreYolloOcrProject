"""Train a custom YOLO marking-region detector after labelling your own images."""
import argparse
from pathlib import Path

from ultralytics import YOLO


# Put labelled images under dataset/images/{train,val} and YOLO-format .txt labels
# under dataset/labels/{train,val}. Each image label line: class x_center y_center width height
# normalized to 0..1. Use class 0 for the whole tyre-size text region.


def ensure_dataset_ready():
    """Fail early if the dataset folders are empty or missing."""
    base = Path(__file__).resolve().parent
    train_images = base / "dataset" / "images" / "train"
    val_images = base / "dataset" / "images" / "val"
    train_labels = base / "dataset" / "labels" / "train"
    val_labels = base / "dataset" / "labels" / "val"

    missing = []
    for folder in [train_images, val_images, train_labels, val_labels]:
        if not folder.exists():
            missing.append(str(folder))

    if missing:
        raise FileNotFoundError(
            "Missing dataset folders: " + ", ".join(missing)
            + "\nCreate them and add your YOLO-labelled tyre-marking images."
        )

    if not any(train_images.iterdir()) or not any(train_labels.iterdir()):
        raise FileNotFoundError(
            "Training dataset is empty. Add labelled images to "
            f"{train_images} and {train_labels}."
        )

    if not any(val_images.iterdir()) or not any(val_labels.iterdir()):
        raise FileNotFoundError(
            "Validation dataset is empty. Add validation images to "
            f"{val_images} and {val_labels}."
        )


def main():
    parser = argparse.ArgumentParser(description="Train a YOLO model for tyre sidewall text detection")
    parser.add_argument("--epochs", type=int, default=180)
    parser.add_argument("--imgsz", type=int, default=960)
    parser.add_argument("--batch", type=int, default=2)
    parser.add_argument("--device", type=str, default="cpu")
    parser.add_argument("--weights", type=str, default="yolo11n.pt")
    args = parser.parse_args()

    ensure_dataset_ready()

    model = YOLO(args.weights)

    # Training configuration tuned for small text on tyres under varied lighting.
    model.train(
        data="data.yaml",
        epochs=args.epochs,
        imgsz=args.imgsz,
        batch=args.batch,
        patience=30,
        project="runs/tyre_marking",
        name="yolo11n_text_region",
        workers=2,
        device=args.device,
        hsv_h=0.02,
        hsv_s=0.8,
        hsv_v=0.65,
        degrees=20.0,
        translate=0.12,
        scale=0.6,
        fliplr=0.5,
        flipud=0.1,
        mosaic=1.0,
        mixup=0.15,
        copy_paste=0.05,
        erasing=0.35,
        perspective=0.05,
        shear=0.0,
        box=0.05,
        cls=0.5,
        dfl=1.5,
    )

    best_pt = "runs/tyre_marking/yolo11n_text_region/weights/best.pt"
    print(f"Training finished. Best weights saved to: {best_pt}")

    print("Exporting best weights to ONNX format...")
    trained_model = YOLO(best_pt)
    onnx_path = trained_model.export(format="onnx", imgsz=640)
    print(f"ONNX model exported: {onnx_path}")
    print("To deploy to the Android app, copy the .onnx model to:")
    print("  android_app/app/src/main/assets/tyre_detector.onnx")


if __name__ == "__main__":
    main()
