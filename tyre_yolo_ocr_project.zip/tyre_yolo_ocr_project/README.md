# VehicleScan PRO — On-Device YOLO + OCR (Zero Server / No Flask)

A completely offline, standalone Android application with on-device AI integration for:
1. **VIN Scanning**: On-device neural OCR + ISO 3779 character validation.
2. **Tyre Scanning**: On-device YOLO region detection + neural OCR + rule-based tyre size specification parsing (`Width / Aspect R Rim Load Speed`).

**Zero server required**: No Flask, no web servers, no local networking, no API configuration. All model inference and text parsing execute directly on the Android device hardware.

---

## Architecture Overview

```
+-------------------------------------------------------------------------+
|                           ANDROID DEVICE (100% OFFLINE)                 |
|                                                                         |
|  [ CameraX Live Viewfinder / Gallery Picker ]                           |
|                         |                                               |
|         +---------------+---------------+                               |
|         |                               |                               |
|         v (VIN Mode)                    v (Tyre Mode)                   |
|   Google ML Kit OCR              ONNX Runtime YOLO Detector             |
|   (On-Device Neural Engine)      (tyre_detector.onnx in assets/)        |
|         |                               |                               |
|         |                        Crops Sidewall Region                  |
|         |                               |                               |
|         |                        Google ML Kit OCR                      |
|         |                               |                               |
|         v                               v                               |
|   VinParser.kt                   TyreParser.kt                          |
|   (17-char ISO 3779 regex)       (Tyre size & speed rating parser)      |
|         |                               |                               |
|         +---------------+---------------+                               |
|                         |                                               |
|                         v                                               |
|             [ Instant Result Modal ]                                    |
+-------------------------------------------------------------------------+
```

---

## 1. Android Application (`android_app`)

The Android application is built with Kotlin and Jetpack:
- **YOLO Detector**: Microsoft ONNX Runtime Mobile (`com.microsoft.onnxruntime:onnxruntime-android`) executing `tyre_detector.onnx` bundled in `app/src/main/assets/`.
- **OCR Engine**: Google ML Kit Text Recognition (`com.google.mlkit:text-recognition`), running 100% offline.
- **Camera**: CameraX with live viewfinder and hardware flash control.
- **Fallback**: Intelligent viewfinder reticle cropping if custom YOLO weights are not loaded.

### Build the APK
```bash
cd android_app
./gradlew assembleDebug
```
The output APK will be generated at:
`android_app/app/build/outputs/apk/debug/app-debug.apk`

Install on connected device:
```bash
./gradlew installDebug
```

---

## 2. Python Backend Model Pipeline (`app.py`)

Flask and web server routes have been completely removed. `app.py` is now a standalone model utility for training, local testing, and exporting weights directly to the Android app.

### CLI Testing
```bash
# Test VIN OCR locally:
python app.py --mode vin --image path/to/vin.jpg

# Test Tyre detection + OCR locally:
python app.py --mode tyre --image path/to/tyre.jpg
```

### Export Custom YOLO Weights to Android
When you finish training your custom tyre YOLO model with `train_yolo.py`:
```bash
# Automatically exports weights to ONNX and places them into Android assets:
python app.py --export-android --weights models/best.pt
```
This automatically updates `android_app/app/src/main/assets/tyre_detector.onnx`.
